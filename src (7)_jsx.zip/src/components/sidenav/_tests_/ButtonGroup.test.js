// src/components/__tests__/custombutton.test.jsx

import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import ButtonGroup from '../custombutton';
import { BUTTON_CONFIGS } from '../constants';

describe('ButtonGroup Component', () => {
  const mockOnReset = jest.fn();

  it('renders all buttons', () => {
    render(<ButtonGroup onReset={mockOnReset} />);
    BUTTON_CONFIGS.forEach(button => {
      expect(screen.getByText(button.text)).toBeInTheDocument();
    });
  });

  it('calls onReset when Reset button is clicked', () => {
    render(<ButtonGroup onReset={mockOnReset} />);
    const resetButton = screen.getByText('Reset');
    fireEvent.click(resetButton);
    expect(mockOnReset).toHaveBeenCalled();
  });
});