// src/components/__tests__/SideNav.test.js

import React from 'react';
import { render, screen } from '@testing-library/react';
import { BrowserRouter as Router } from 'react-router-dom';
import SideNav from '../sidenav'
import { MENU_ITEMS } from '../../components/constants';

describe('SideNav Component', () => {
  it('renders without crashing', () => {
    render(
      <Router>
        <SideNav />
      </Router>
    );
    MENU_ITEMS.forEach(item => {
      expect(screen.getByText(item.label)).toBeInTheDocument();
    });
  });
});