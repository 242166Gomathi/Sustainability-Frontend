// src/components/SideNav.jsx

import React from 'react';
import { Menu } from 'antd';
import { Link } from 'react-router-dom';
import './sidenav.css';
import { MENU_ITEMS } from '../../components/constants';

const SideNav = () => {
  return (
    <Menu mode="inline" defaultSelectedKeys={['dashboard']} className="side-nav-menu">
      {MENU_ITEMS.map((item) => (
        <Menu.Item key={item.key} icon={item.icon}>
          <Link to={item.path}>{item.label}</Link>
        </Menu.Item>
      ))}
    </Menu>
  );
};

export default SideNav;
