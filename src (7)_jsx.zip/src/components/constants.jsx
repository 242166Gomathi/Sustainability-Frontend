// src/components/constants.js

import {
    HomeOutlined,
    FileTextOutlined,
    StarOutlined,
} from '@ant-design/icons';

// Constants for header.jsx
export const LOGO_SRC = 'OIP.jpg';
export const LOGO_ALT = 'SUSTAINABILITY Logo';
export const LOGO_TEXT = 'SUSTAINABILITY  PROGRAM';
export const USERNAME_PLACEHOLDER = '';

// Constants for sidenav.jsx with Ant Design icons
export const MENU_ITEMS = [
    { key: 'dashboard', label: 'Dashboard', path: '/dashboard', icon: <HomeOutlined /> },
    { key: 'reporting', label: 'Reporting', path: '/reporting', icon: <FileTextOutlined /> },
    { key: 'goals', label: 'Goals', path: '/goals', icon: <StarOutlined /> },
];
// Tabs and buttons configuration
export const TAB_LIST_NO_TITLE = [
    { key: 'preSurvey', tab: 'PreSurvey' },
    { key: 'cdpDetails', tab: 'CDP Details' },
    { key: 'reporting', tab: 'Reporting' },
];

export const REPORTING_NESTED_TABS = [
    { key: 'energy', tab: 'Energy' },
    { key: 'waste', tab: 'Waste' },
    { key: 'packaging', tab: 'Packaging' },
];

export const BUTTON_CONFIGS = [
    { text: 'Reset', onClick: () => { }, style: { borderRadius: '11px', fontSize: '16px', padding: '1px 8px', height: '40px', width: '90px', textAlign: 'center', marginLeft: '-90px' } },
    { text: 'Save', onClick: () => { }, style: { borderRadius: '11px', fontSize: '16px', padding: '1px 8px', height: '40px', width: '90px', textAlign: 'center' } },
    { text: 'Next', onClick: () => { }, style: { borderRadius: '11px', fontSize: '16px', padding: '1px 8px', height: '40px', width: '90px', textAlign: 'center' } }
];

export const LABELS = {
    SUPPLIER_NAME: 'Supplier Name',
    PROJECT_CREATION_YEAR: 'Project Creation Year',
    PERIOD_START_DATE: 'Period Start Date',
    PROJECT_END_YEAR: 'Project End Year',
    CDP_DATA_AVAILABLE: 'Is CDP data available?',
    OTHER_DATA_TO_REPORT: 'Do you have any other data to report?',
    FOCUS_AREA: 'Focus Area',
    ENERGY: 'Energy',
    WASTE: 'Waste',
    PACKING: 'Packing',
    OTHER: 'Others',
    // PDF_DOWNLOAD: 'PDF Download',
};