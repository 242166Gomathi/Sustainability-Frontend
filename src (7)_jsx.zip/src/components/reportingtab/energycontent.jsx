import React, { useState } from 'react';
import { Switch, Row, Col, Button } from 'antd';
import './energycontent.css'; // Ensure this path is correct

const EnergyContent = ({ data }) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleToggleChange = (checked) => {
    setIsOpen(checked);
  };

  const handleAdd = () => {
    // Add logic here
    console.log('Add button clicked');
  };

  const handleDelete = () => {
    // Delete logic here
    console.log('Delete button clicked');
  };

  return (
    <div className='energy-content-container'>
      <Row justify="end" align="middle" gutter={16} style={{ marginBottom: 16 }}>
        <Col>
          <Switch checked={isOpen} onChange={handleToggleChange} />
          <span className='toggle-status'>{isOpen ? 'Yes' : 'No'}</span>
        </Col>
        <Col>
          <Button onClick={handleAdd} type="primary" className='action-button'>Add</Button>
        </Col>
        <Col>
          <Button onClick={handleDelete} type="danger" className='action-button'>Delete</Button>
        </Col>
      </Row>
      {isOpen && (
        <div className='details-section'>
          <ul>
            {data.map((item) => (
              <li key={item.id}>
                {item.type}: {item.amount}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default EnergyContent;
