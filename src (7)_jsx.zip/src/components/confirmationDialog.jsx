// // src/components/ButtonGroup.js
// import React from 'react';
// import { Button } from 'antd';
// import './custombutton.css'; // Import the CSS file for styling


// const ConfirmationDialog = ({ visible, onOk, onCancel, title, content }) => {
//   return (
//     <Modal
//       visible={visible}
//       title={title}
//       onOk={onOk}
//       onCancel={onCancel}
//       okText="Yes"
//       cancelText="No"
//     >
//       {content}
//     </Modal>
//   );
// };

// export default ConfirmationDialog;

