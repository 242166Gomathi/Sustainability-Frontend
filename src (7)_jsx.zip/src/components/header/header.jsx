// src/components/AppHeader.jsx

import React from 'react';
import { Layout, Avatar } from 'antd';
import './header.css';
import { UserOutlined } from '@ant-design/icons';
import { LOGO_SRC, LOGO_ALT, LOGO_TEXT, USERNAME_PLACEHOLDER } from '../../components/constants';

const { Header } = Layout;

const AppHeader = () => {
  return (
    <Header className="header">
      <div className="logo">
        <img src={LOGO_SRC} className="logo-icon" alt={LOGO_ALT} />
        <span className="logo-text">{LOGO_TEXT}</span>
      </div>
      <div className="user-profile">
        <Avatar size="large" icon={<UserOutlined />} className="user-avatar" />
        <span className="username">{USERNAME_PLACEHOLDER}</span>
      </div>
    </Header>
  );
};

export default AppHeader;
