// src/components/__tests__/AppHeader.test.js

import React from 'react';
import { render, screen } from '@testing-library/react';
import AppHeader from '../AppHeader';
import { LOGO_TEXT } from '../../components/constants';

describe('AppHeader Component', () => {
  it('renders without crashing', () => {
    render(<AppHeader />);
    expect(screen.getByText(LOGO_TEXT)).toBeInTheDocument();
  });

  it('displays the logo', () => {
    render(<AppHeader />);
    const logoImage = screen.getByAltText('SUSTAINABILITY Logo');
    expect(logoImage).toBeInTheDocument();
  });
});