import React from 'react';
import { Button, message } from 'antd';
import './custombutton.css'; 
import { BUTTON_CONFIGS } from '../../src/components/constants';
import PropTypes from 'prop-types';

const handleReset = () => {
  console.log('Reset button clicked. Making API call...');

  // Simulating API call using fetch
  fetch('/api/reset', { 
    method: 'DELETE',
    headers: {
      'Content-Type': 'application/json',
    },
   
    body: JSON.stringify({ /* delete request */ }),
  })
    .then(response => {
      if (response.ok) {
        console.log('Reset API call successful.');
        message.success('Reset successful');
      } else {
        console.error('Reset API call failed.');
        message.error('Reset failed');
      }
    })
    .catch(error => {
      console.error('Error during Reset API call:', error);
      message.error('An error occurred during reset');
    });
};

const ButtonGroup = ({ onReset }) => {
  return (
    <div className="footer-buttons-container">
      {BUTTON_CONFIGS.map((button) => (
        <Button
          key={button.text} 
          className="footer-button"
          onClick={button.text === 'Reset' ? onReset : button.onClick}
          style={button.style}
        >
          {button.text}
        </Button>
      ))}
    </div>
  );
};

ButtonGroup.propTypes = {
  onReset: PropTypes.func.isRequired,
};

export default ButtonGroup;
