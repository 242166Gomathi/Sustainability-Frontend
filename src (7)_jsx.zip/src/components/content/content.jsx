import React from 'react';
import { Layout } from 'antd';
import './content.css';

const { Content } = Layout;

const AppContent = () => {
  return (
    <Content className="site-layout-background" style={{ padding: '24px', minHeight: 280 }}>
      <h1>Sustainability Reporting</h1>
      <p>Details of your sustainability initiatives will be shown here.</p>
      {/* Add the content you need */}
    </Content>
  );
};

export default AppContent;
