import React from 'react';
import './goals.css';

const Goals = () => {
  return (
    <div className="goals">
      <h1>Goals</h1>
      <p>Set and track your sustainability goals here.</p>
    </div>
  );
};

export default Goals;
