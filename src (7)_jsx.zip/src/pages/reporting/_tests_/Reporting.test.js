// src/pages/reporting/__tests__/reporting.test.jsx

import React from 'react';
import { render, screen } from '@testing-library/react';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import Reporting from '../reporting';

const mockStore = configureStore([thunk]);

jest.mock('../../../redux/slices/energyslice', () => ({
  getEnergyData: jest.fn(),
}));

describe('Reporting Component', () => {
  let store;

  beforeEach(() => {
    store = mockStore({
      survey: {
        supplierName: '',
        projectCreationYear: '',
        periodStartDate: null,
        projectEndYear: null,
        isCdpDataAvailable: false,
        otherDataToReport: false,
        focusAreas: [],
      },
      energy: {
        data: [],
      },
    });
  });

  it('renders without crashing', () => {
    render(
      <Provider store={store}>
        <Reporting />
      </Provider>
    );
    expect(screen.getByText('PreSurvey')).toBeInTheDocument();
  });

  it('displays all tabs', () => {
    render(
      <Provider store={store}>
        <Reporting />
      </Provider>
    );
    expect(screen.getByText('PreSurvey')).toBeInTheDocument();
    expect(screen.getByText('CDP Details')).toBeInTheDocument();
    expect(screen.getByText('Reporting')).toBeInTheDocument();
  });
});