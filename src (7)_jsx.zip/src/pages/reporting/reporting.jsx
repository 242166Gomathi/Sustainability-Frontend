import React, { useEffect, useState } from 'react';
import { Card, Form, Input, DatePicker, Switch, Checkbox, Tabs, Row, Col, Modal } from 'antd';
import moment from 'moment';
import './reporting.css';
import ButtonGroup from '../../components/custombutton';
import { useDispatch, useSelector } from 'react-redux';
import { getEnergyData } from '../../redux/slices/energyslice';
import { updateSurvey, resetSurvey } from '../../redux/slices/surveyslice';
import { TAB_LIST_NO_TITLE, REPORTING_NESTED_TABS, LABELS } from '../../components/constants';
import EnergyContent from '../../components/reportingtab/energycontent';
import WasteContent from '../../components/reportingtab/wastecontent';

const { TabPane } = Tabs;
const dateFormat = 'DD-MM-YYYY';

const Reporting = () => {
  const dispatch = useDispatch();
  const [form] = Form.useForm();
  const [activeTabKey, setActiveTabKey] = useState('preSurvey');

  const surveyState = useSelector((state) => state.survey || {});
  const { data: energyData } = useSelector((state) => state.energy || {});

  useEffect(() => {
    dispatch(getEnergyData());
  }, [dispatch]);

  useEffect(() => {
    form.setFieldsValue({
      supplierName: surveyState.supplierName || '',
      projectCreationYear: surveyState.projectCreationYear || '',
      periodStartDate: surveyState.periodStartDate ? moment(surveyState.periodStartDate, dateFormat) : null,
      projectEndYear: surveyState.projectEndYear ? moment(surveyState.projectEndYear, dateFormat) : null,
      isCdpDataAvailable: surveyState.isCdpDataAvailable || false,
      otherDataToReport: surveyState.otherDataToReport || false,
      focusAreas: surveyState.focusAreas || [],
    });
  }, [surveyState, form]);

  const onTabChange = (key) => {
    setActiveTabKey(key);
  };

  const handleFieldChange = (field) => (e) => {
    const { value } = e.target;
    dispatch(updateSurvey({ [field]: value }));
  };

  const handleDateChange = (field) => (date, dateString) => {
    dispatch(updateSurvey({ [field]: dateString }));
  };

  const handleSwitchChange = (field) => (checked) => {
    dispatch(updateSurvey({ [field]: checked }));
  };

  const handleCheckboxChange = (checkedValues) => {
    dispatch(updateSurvey({ focusAreas: checkedValues }));
  };

  const handleReset = () => {
    Modal.confirm({
      title: 'Are you sure you want to reset?',
      content: 'This will clear all your unsaved changes.',
      okText: 'Yes',
      cancelText: 'No',
      onOk() {
        form.resetFields(); // Clear form fields
        dispatch(resetSurvey()); // Reset Redux state
        console.log('Reset successful');
      },
      onCancel() {
        console.log('Reset canceled');
      },
    });
  };
  

  const nestedTabContent = {
    energy: <EnergyContent data={energyData} />,
    waste: <WasteContent data={energyData} />,
    packaging: <p>{LABELS.PACKAGING} content</p>,
  };

  const contentListNoTitle = {
    preSurvey: (
      <Form layout="vertical">
        {/* Row 1 - Supplier Name and Project Creation Year */}
        <Row gutter={1}>
          <Col span={12}>
            <div className="form-item-row">
              <label>{LABELS.SUPPLIER_NAME}</label>
              <Input
                value={surveyState.supplierName || ''}
                className="custom-input"
                onChange={handleFieldChange('supplierName')}
              />
            </div>
          </Col>
          <Col span={12}>
            <div className="form-item-row">
              <label>{LABELS.PROJECT_CREATION_YEAR}</label>
              <Input
                value={surveyState.projectCreationYear || ''}
                className="custom-input"
                onChange={handleFieldChange('projectCreationYear')}
              />
            </div>
          </Col>
        </Row>

        {/* Row 2 - Period Start Date and Project End Year */}
        <Row gutter={1}>
          <Col span={12}>
            <div className="form-item-row">
              <label>{LABELS.PERIOD_START_DATE}</label>
              <DatePicker
                value={surveyState.periodStartDate ? moment(surveyState.periodStartDate, dateFormat) : null}
                format={dateFormat}
                picker="date" // Regular date picker for full date selection
                style={{ width: '44%' }} // Adjust width to be consistent
                onChange={handleDateChange('periodStartDate')}
              />
            </div>
          </Col>
          <Col span={12}>
            <div className="form-item-row">
              <label>{LABELS.PROJECT_END_YEAR}</label>
              <DatePicker
                value={surveyState.projectEndYear ? moment(surveyState.projectEndYear, dateFormat) : null}
                format={dateFormat}
                picker="date" // Regular date picker for full date selection
                style={{ width: '44%' }} // Adjust width to be consistent
                onChange={handleDateChange('projectEndYear')}
              />
            </div>
          </Col>
        </Row>

        {/* Row 3 - CDP Data Available and Other Data to Report */}
        <Row gutter={1}>
          <Col span={12}>
            <div className="form-item-row">
              <label>{LABELS.CDP_DATA_AVAILABLE}</label>
              <Switch
                checked={surveyState.isCdpDataAvailable || false}
                checkedChildren="Yes"
                unCheckedChildren="No"
                onChange={handleSwitchChange('isCdpDataAvailable')}
                style={{ width: '15%' }} 
              />
            </div>
          </Col>
          <Col span={12}>
            <div className="form-item-row">
              <label>{LABELS.OTHER_DATA_TO_REPORT}</label>
              <Switch
                checked={surveyState.otherDataToReport || false}
                checkedChildren="Yes"
                unCheckedChildren="No"
                onChange={handleSwitchChange('otherDataToReport')}
                style={{ width: '15%' }}
              />
            </div>
          </Col>
        </Row>

        {/* Row 4 - Focus Area */}
        <Row gutter={1}>
          <Col span={50}>
            <div className="form-item-row">
              <label>{LABELS.FOCUS_AREA}</label>
              <Checkbox.Group value={surveyState.focusAreas || []} onChange={handleCheckboxChange}>
                <Row gutter={70}>
                  <Col span={6}><Checkbox value="energy" style={{ marginLeft: '85px' }}>{LABELS.ENERGY}</Checkbox></Col>
                  <Col span={6}><Checkbox value="waste" style={{ marginLeft: '30px' }}>{LABELS.WASTE}</Checkbox></Col>
                  <Col span={6}><Checkbox value="packing" style={{ marginLeft: '-30px' }}>{LABELS.PACKING}</Checkbox></Col>
                  <Col span={6}><Checkbox value="other" style={{ marginLeft: '-80px' }}>{LABELS.OTHER}</Checkbox></Col>
                </Row>
              </Checkbox.Group>
            </div>
          </Col>
        </Row>
      </Form>
    ),
    cdpDetails: <p>CDP Details content</p>,
    reporting: (
      <Tabs defaultActiveKey="energy" className="nested-tabs">
        {REPORTING_NESTED_TABS.map((tab) => (
          <TabPane tab={tab.tab} key={tab.key}>
            {nestedTabContent[tab.key]}
          </TabPane>
        ))}
      </Tabs>
    ),
  };

  return (
    <div className="reporting">
      <div className="header-container">
        {/* Optional PDF download button */}
      </div>
      <div className="content-container">
        <Card
          className="custom-card"
          tabList={TAB_LIST_NO_TITLE}
          activeTabKey={activeTabKey}
          onTabChange={onTabChange}
          tabProps={{ size: 'large' }}
        >
          {contentListNoTitle[activeTabKey]}
        </Card>
      </div>
      <div className="footer-container">
        <ButtonGroup onReset={handleReset} />
      </div>
    </div>
  );
};

export default Reporting;
