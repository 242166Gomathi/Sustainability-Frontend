import axios from 'axios';

export const fetchEnergyData = async () => {
  const response = await axios.get('/api/energy-data');
  return response.data;
};
