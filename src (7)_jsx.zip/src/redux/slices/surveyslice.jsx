import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  supplierName: '',
  projectCreationYear: '', // Consider changing this to a date if needed
  periodStartDate: null, // Change to null to handle empty date
  projectEndYear: null, // Change to null to handle empty date
  isCdpDataAvailable: false, // Default to false, adjust as needed
  otherDataToReport: false, // Default to false, adjust as needed
  focusAreas: [], // Start with an empty array or default values if needed
};

const surveySlice = createSlice({
  name: 'survey',
  initialState,
  reducers: {
    updateSurvey(state, action) {
      return { ...state, ...action.payload };
    },
    resetSurvey() {
      return initialState; // Resets state to initialState
    },
  },
});

export const { updateSurvey, resetSurvey } = surveySlice.actions;
export default surveySlice.reducer;
