// src/redux/slices/__tests__/surveySlice.test.js

import surveyReducer, { updateSurvey, resetSurvey } from '../surveyslice';

describe('surveySlice', () => {
  const initialState = {
    supplierName: '',
    projectCreationYear: '',
    periodStartDate: null,
    projectEndYear: null,
    isCdpDataAvailable: true,
    otherDataToReport: true,
    focusAreas: ['energy', 'waste', 'packing', 'other'],
  };

  it('should handle initial state', () => {
    expect(surveyReducer(undefined, { type: 'unknown' })).toEqual(initialState);
  });

  it('should handle updateSurvey', () => {
    const actual = surveyReducer(initialState, updateSurvey({ supplierName: 'Test Supplier' }));
    expect(actual.supplierName).toEqual('Test Supplier');
  });

  it('should handle resetSurvey', () => {
    const actual = surveyReducer({ ...initialState, supplierName: 'Test Supplier' }, resetSurvey());
    expect(actual).toEqual(initialState);
  });
});