import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { fetchEnergyData } from '../../services/reportingservice';

const initialState = {
  data: [],
  loading: false,
  error: null,
};

export const getEnergyData = createAsyncThunk(
  'energy/getEnergyData',
  async () => {
    const data = await fetchEnergyData();
    return data;
  }
);

const energySlice = createSlice({
  name: 'energy',
  initialState,
  extraReducers: (builder) => {
    builder
      .addCase(getEnergyData.pending, (state) => {
        state.loading = true;
      })
      .addCase(getEnergyData.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(getEnergyData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      });
  },
});

export default energySlice.reducer;
