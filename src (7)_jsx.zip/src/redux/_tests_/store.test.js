// src/redux/__tests__/store.test.js

import store from '../store';

describe('Redux Store', () => {
  it('should have the correct initial state', () => {
    const initialState = store.getState();
    expect(initialState).toHaveProperty('survey');
    expect(initialState).toHaveProperty('energy');
  });
});