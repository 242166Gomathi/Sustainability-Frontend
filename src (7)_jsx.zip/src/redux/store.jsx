import { configureStore } from '@reduxjs/toolkit';
import energyReducer from './slices/energyslice';
import surveyReducer from './slices/surveyslice';

const store = configureStore({
  reducer: {
    survey: surveyReducer,
    energy: energyReducer,
  },
});

export default store;
